//Part 3: Multiplexer and ALU
#include "alu.h"

int mux(int sel, int a, int b)
{
	// TODO
	return -1;
}

uint8_t alu(uint8_t a, uint8_t b, int op1, int op0)
{
	// TODO
	return -1;
}
