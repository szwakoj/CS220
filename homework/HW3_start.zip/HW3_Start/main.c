// Part 4: Test Harness
#include <stdio.h>
#include <stdint.h>
#include "alu.h"

// Write all test functions and them being ran in this file

int main(void)
{

	return 0;
}
