#include "alu.h"


int nand(int a, int b)
{
	return !(a & b);
}


// Part 1: Logic Gates

int not(int a)
{
	// TODO 
	return -1;
}

int and(int a, int b)
{
	// TODO 
	return -1;
}

int or(int a, int b)
{
	// TODO 
	return -1;
}

int xor(int a, int b)
{
	// TODO 
	return -1;
}

int nor(int a, int b)
{
	// TODO 
	return -1;
}

int xnor(int a, int b)
{
	// TODO 
	return -1;
}
